# WorldAnarchyChat.com — front-end prototype

A responsive anonymous-style public chat room interface inspired by the supplied screenshots.

## Run it
Open `index.html` directly in a modern browser, or serve this folder with any static web server.

## Included
- Dark, minimal chat-room layout
- General, random, music, gaming, and late-night rooms
- Send messages locally in the current browser session
- Choose and remember a nickname with localStorage
- Add local demo rooms
- Responsive mobile layout and light/dark toggle

## Important
This is a front-end prototype. Messages are not shared between visitors and disappear on refresh. A real public chat needs a backend (for example, WebSocket server + database), moderation/reporting tools, rate limiting, and privacy/security controls.
